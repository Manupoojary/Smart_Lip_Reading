import cv2
import tensorflow as tf


import streamlit as st
# from modelutil import load_model

# # Set the layout to the OpenCV window as wide
# cv2.namedWindow('LipBuddy', cv2.WINDOW_NORMAL)
# cv2.setWindowProperty('LipBuddy', cv2.WND_PROP_FULLSCREEN, cv2.WINDOW_FULLSCREEN)

# # Load the LipNet model and other necessary utilities
# model = load_model()  # Assuming you have a function named load_model() that loads your model
# # Load other required utilities as well

# # Create the webcam capture
# cap = cv2.VideoCapture(0)  # Use the default camera (index 0)

# while True:
#     # Read a frame from the webcam
#     ret, frame = cap.read()

#     # Perform any necessary preprocessing on the frame (e.g., resizing, normalization)

#     # Perform lip reading inference using your LipNet model
#     # result = model.predict(frame)

#     # Perform any necessary post-processing on the result (e.g., converting numeric output to characters)

#     # Display the processed frame on the OpenCV window
#     cv2.imshow('LipBuddy', frame)

#     # Exit the loop if 'q' key is pressed
#     if cv2.waitKey(1) & 0xFF == ord('q'):
#         break

# # Release the webcam capture and close the OpenCV window
# cap.release()
# cv2.destroyAllWindows()


col1, col2 = st.columns(2)

with col1:
    img_file_buffer = st.camera_input("Take a picture")
    if img_file_buffer is not None:
        # To read image file buffer as a 3D uint8 tensor with TensorFlow:
        bytes_data = img_file_buffer.getvalue()
        img_tensor = tf.io.decode_image(bytes_data, channels=3)

    # Check the type of img_tensor:
    # Should output: <class 'tensorflow.python.framework.ops.EagerTensor'>
        st.write(type(img_tensor))

    # Check the shape of img_tensor:
    # Should output shape: (height, width, channels)
        st.write(img_tensor.shape)